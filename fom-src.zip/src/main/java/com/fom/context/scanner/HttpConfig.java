package com.fom.context.scanner;

import com.fom.context.IConfig;

/**
 * 
 * @author shanhm
 * @date 2018年12月23日
 *
 */
public interface HttpConfig extends IConfig {

}
