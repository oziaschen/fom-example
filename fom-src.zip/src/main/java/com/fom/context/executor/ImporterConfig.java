package com.fom.context.executor;

/**
 * 
 * @author shanhm
 * @date 2018年12月23日
 *
 */
public interface ImporterConfig {
	
	/**
	 * 获取入库时的批处理数
	 * @return
	 */
	int getBatch();

}
