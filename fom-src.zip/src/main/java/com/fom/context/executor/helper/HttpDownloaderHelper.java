package com.fom.context.executor.helper;

import java.io.File;
import java.io.InputStream;

/**
 * 
 * @author shanhm
 * @date 2019年1月22日
 *
 */
public class HttpDownloaderHelper implements DownloaderHelper {

	@Override
	public InputStream open(String url) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void download(String url, File file) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean delete(String url) throws Exception {
		// TODO Auto-generated method stub
		return false;
	}

}
