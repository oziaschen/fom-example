package com.fom.context.config;

/**
 * 
 * @author shanhm
 * @date 2018年12月23日
 *
 */
public class HttpZipDownloaderConfig extends ZipDownloaderConfig implements IHttpConfig {

	protected HttpZipDownloaderConfig(String name) {
		super(name);
	}

}
