package com.fom.context.config;

/**
 * 
 * @author shanhm
 * @date 2019年1月10日
 *
 */
public class HttpImporterConfig {

}
