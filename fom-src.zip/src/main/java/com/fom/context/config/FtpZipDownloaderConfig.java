package com.fom.context.config;

/**
 * 
 * @author shanhm
 * @date 2018年12月23日
 *
 */
public class FtpZipDownloaderConfig extends ZipDownloaderConfig implements IFtpConfig {

	protected FtpZipDownloaderConfig(String name) {
		super(name);
	}

}
