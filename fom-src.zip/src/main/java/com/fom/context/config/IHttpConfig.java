package com.fom.context.config;

/**
 * 
 * @author shanhm
 * @date 2018年12月23日
 *
 */
public interface IHttpConfig extends IConfig {

}
