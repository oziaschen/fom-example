package com.fom.context.config;

/**
 * 
 * @author shanhm
 * @date 2018年12月23日
 *
 */
public class FtpDownloaderConfig extends DownloaderConfig implements IFtpConfig {

	protected FtpDownloaderConfig(String name) {
		super(name);
	}

}
