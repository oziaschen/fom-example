package com.fom.context;

/**
 * 
 * @author shanhm
 * @date 2019年1月22日
 *
 */
public interface Executor {

	void exec() throws Exception; 
	
}
