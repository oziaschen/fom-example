package com.fom.defaulter;

import com.fom.context.Context;
import com.fom.context.Executor;
import com.fom.context.executor.Downloader;
import com.fom.context.executor.helper.HdfsDownloaderHelper;

/**
 * 
 * @author shanhm
 * @date 2018年12月23日
 *
 */
public class HdfsDownloader<E extends HdfsDownloaderConfig> extends Context<E> {
	
	protected HdfsDownloader(String name, String path) {
		super(name, path); 
	}

	@Override
	protected final void exec(E config) throws Exception {
		HdfsDownloaderHelper helper = new HdfsDownloaderHelper(config.getFs(), config.isDelSrc());
		Executor executor = new Downloader(name, sourceUri, config, helper);
		executor.exec();
	}
	
}
