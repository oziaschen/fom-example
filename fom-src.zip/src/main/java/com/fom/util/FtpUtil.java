package com.fom.util;

/**
 * 
 * @author shanhm
 * @date 2019年1月10日
 *
 */
public class FtpUtil {

}
