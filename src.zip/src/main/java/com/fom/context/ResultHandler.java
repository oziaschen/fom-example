package com.fom.context;

/**
 * 
 * @author shanhm
 *
 */
public interface ResultHandler {

	void handle(Result result) throws Exception;
}
