package com.fom.context.reader;

import java.io.IOException;

/**
 * 
 * @author shanhm
 *
 */
public class ExcelReader implements Reader {

	@Override
	public String readLine() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void close() throws IOException {
		// TODO Auto-generated method stub
		
	}
}
