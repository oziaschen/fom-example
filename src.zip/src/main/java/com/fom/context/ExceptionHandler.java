package com.fom.context;

/**
 * 
 * @author shanhm
 *
 */
public interface ExceptionHandler {
	
	/**
	 * @param e Throwable
	 */
	void handle(Throwable e);

}
