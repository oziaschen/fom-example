package com.fom.util;

/**
 * 
 * @author shanhm
 *
 */
public class FtpUtil {

}
